package com.example.practice_01

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
