package com.example.basic_login_form

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
