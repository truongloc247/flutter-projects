package com.example.practice_02

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
